export interface Cliente {
    _id: number;
    nombre: string;
    direccion:string;
    telefono:number;
    email:string;
    tipoDocumento:String;
    numeroDocumento:string;
    estado:boolean;
}
