export interface loginInterface{
    login: string;
    password: string;
};
