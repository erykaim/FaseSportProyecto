import { Injectable } from '@angular/core';
import { enviromment } from '../../../enviroments/envrroment';
import { HttpClient } from '@angular/common/http';
import { Cliente } from '../../core/interfaces/cliente';
import { ClienteModel } from '../../core/models/clienteModel';

//variable global 
const base_url = enviromment.base_url;



@Injectable({
  providedIn: 'root'
})
export class ClientesService {


  constructor( private  httpClient: HttpClient) { }

  getClientes(){
    return this.httpClient.get(`${base_url}/cliente`)
  }

  crearClientes(cliente: ClienteModel){
    return this.httpClient.post(`${base_url}/cliente`,cliente)
  }
}
