// las TP, endopint o url de las api que voy a consumir

export const enviromment= {
    production: false,
    base_url: 'http://localhost:4000/api/v1',
};